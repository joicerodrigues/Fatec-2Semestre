<?php

//variaveis para receber valor do form via metodo $_POST
$nome = $_POST['nome'];
$ra = $_POST['ra'];
$email = $_POST['email'];
$bd = 'bd.txt';


//v if que irá verificar se o arquivo "bd" existe
        $filename = $bd;
        if(!file_exists($bd)){
            $handle = fopen($bd, "w");
        } else {
            $handle = fopen($bd, "a");
        }
//escrevendo o valor recbido pelas variaveis para o stream de arquivo apontado por handle
        fwrite($handle, "Nome: ".$nome." | ");
        fwrite($handle, "RA: ".$ra." |  ");
        fwrite($handle, "Email: ".$email."\r\n");
        fflush($handle);
        fclose($handle);
        $handle = fopen($bd, "r");       
        fclose($handle);
header("location: home.php");
    exit;
?>