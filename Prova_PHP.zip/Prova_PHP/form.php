
<!DOCTYPE html>
<html lang="pt_BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.0/font/bootstrap-icons.css">
    <style type="text/css">
        body{ 
            font: 14px sans-serif; 
        }
        .wrapper{ 
            width: 350px;
            padding: 20px;
            border-radius: 10%;
            border-color: blanchedalmond;
            background-color: rgb(168, 236, 225); 
        }
        .logo{
            padding-left: 65px !important;
        }
        .logo img{
            border-radius: 100% !important;
        }
        .container{
            padding-left: 30%;
            padding-top: 5% !important;
            align-items: center !important;
        }
        .wrapper{
            
        }
        .form-group input{
            border-radius: 10px !important;
        }
        .title{
            text-align: center !important;
        }
        .button{
            padding-left: 35% !important;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="wrapper">
            <div class="logo">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR4Xmmd1rvHHGt8tHpCZT8hZ4o12Z39fffrTP__ptX_TqySMoWoozegyq47Nzy8wmR6JpA&usqp=CAU" width="70%" height="70%">
            </div>
            <div class="title">
                <h2>Cadastrar</h2>
                <p>Favor inserir os dados.</p>
            </div>
            <form action="bd.php" method="POST">
                <div class="form-group">
                    <label>Nome</label>
                    <input id="nome" type="text" name="nome" class="form-control" value="">
                    <span class="help-block"></span>
                </div>    
                <div class="form-group">
                    <label>RA</label>
                    <input id="ra" type="text" name="ra" class="form-control" value="" maxlength="7">
                    <span class="help-block"></span>
                </div>
                <div class="form-group">
                    <label>E-mail</label>
                    <input id="email" type="text" name="email" class="form-control" value="" maxlength="37">
                    <span class="help-block"></span>
                </div>
                <div class="form-group">
                    <div class="button">
                        <input type="submit" class="btn btn-primary" value="Cadastrar">
                    </div>
                </div>
            </form>
        </div> 
    </div>   
</body>
</html>