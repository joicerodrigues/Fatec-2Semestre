<?php
 

if($_SERVER["REQUEST_METHOD"] == "POST"){
    session_start();
    if($_POST['username'] == 'joice' and $_POST['password'] == '123321'){
        $_SESSION['loggedin'] = TRUE;
        $_SESSION["username"] = 'Joice Rodrigues';
         header("location: home.php");
    } else {
        $_SESSION['loggedin'] = FALSE;
    }
}
?>
 
<!DOCTYPE html>
<html lang="pt_BR">
<head>
    <meta charset="UTF-8">
    <title>Acessar</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.0/font/bootstrap-icons.css">
    <style type="text/css">
    
    <style type="text/css">
        .wrapper p{
        text-align: center;
        }
        .wrapper h2{
            text-align: center;
        }
        .logo{
            padding-left: 80px !important;
        }
        .container{
            padding-left: 30%;
            padding-top: 5% !important;
            align-items: center !important;
        }
        .wrapper{
            border-radius: 10%;
            border-color: blanchedalmond;
            background-color: rgb(168, 236, 225);
        }
        .button{
            padding-left: 35%;
        }
        body{ 
            font: 14px sans-serif; 
        }

        .wrapper{ 
            width: 350px; padding: 20px; 
        }
        .form-group input{
            border-radius: 10px !important;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="wrapper">
            <div class="logo">
                <img src="https://eba.ufmg.br/pos/profartes/wp-content/uploads/2021/07/icone-de-perfil.png" width="70%" height="70%">
            </div>
            <h2>Login</h2>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" class="form-control" value="joice">
                    <span class="help-block"></span>
                </div>    
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" value="123321">
                    <span class="help-block"></span>
                </div>
                <div class="form-group">
                    <div class="button">
                        <input type="submit" class="btn btn-primary" value="Acessar">
                    </div>
                </div>
            </form>
        </div>    
    </div>
</body>
</html>